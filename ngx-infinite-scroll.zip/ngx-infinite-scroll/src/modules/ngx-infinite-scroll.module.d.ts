export declare class InfiniteScrollModule {
}
